//
//  SceneDelegate.h
//  ios
//
//  Created by wangzhe on 2020/12/1.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

