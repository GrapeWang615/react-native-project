//
//  AppDelegate.h
//  ios
//
//  Created by wangzhe on 2020/12/1.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow * window;

@end

